<!DOCTYPE html>
<html>
<body>

<?php
$xml=simplexml_load_file("note.xml");
print_r($xml);
?>

</body>
</html>