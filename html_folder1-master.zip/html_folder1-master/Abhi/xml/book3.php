<?php
//get attribute value
$xml=simplexml_load_file("bookstore.xml") or die("Error: Cannot create object");
echo $xml->book[0]['category'] . "<br>";
echo $xml->book[1]->title['lang']; 
?>