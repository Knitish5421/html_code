<?php
$xml=simplexml_load_file("example.xml");
echo $xml->getName() . "<br>";

foreach($xml->children() as $child)
  {
  echo $child->getName() . ": " . $child . "<br>";  
	echo $child->TITLE->getName(). ": "  .$child->TITLE .  "<br>" ; 
    echo $child->ARTIST->getName(). ": "  . $child->ARTIST . "<br>"; 
    echo $child->COUNTRY->getName(). ": "  . $child->COUNTRY . "<br>";
	echo $child->COMPANY->getName(). ": "  . $child->COMPANY . "<br> ";
	echo $child->PRICE->getName(). ": "  . $child->PRICE . "<br>";
    echo $child->YEAR->getName(). ": "  .$child->YEAR .  "<br><br>"; 
  }
?>