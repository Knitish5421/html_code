<?php
//PHP SimpleXML - Get Node Values - Loop
$xml=simplexml_load_file("bookstore.xml") or die("Error: Cannot create object");
foreach($xml->children() as $books) { 
    echo $books->title . "<br>";     
} 
?>