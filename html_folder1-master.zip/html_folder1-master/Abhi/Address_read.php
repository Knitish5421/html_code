<!DOCTYPE html>
<html>
	<body>
		<?php

		// Read JSON file
		$json = file_get_contents("Address_details.json");

		//Decode JSON
		$json_data = json_decode($json,true);

		//Print data
		print_r($json_data);

		?>
		</body>
</html>