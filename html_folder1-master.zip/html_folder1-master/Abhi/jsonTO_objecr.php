<?php

$data = '{
	"name": "Abhinash",
	"gender": "male"
}';

$character = json_decode($data);//converting json to object 
echo $character->name ." ,".$character->gender ;//retriving the object element