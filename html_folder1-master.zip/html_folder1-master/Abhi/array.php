<!DOCTYPE html>
<html>
<body>

<?php
$cars = array("Volvo", "BMW", "Toyota"); 
foreach($cars as $value){
	echo "$value</br>";
}

?>

</body>
</html>