<?php  
	$colors = array("red", "green", "blue", "yellow"); 
	$arrlength = count($colors);
	foreach ($colors as $value) {
	  echo "$value <br>";
	  }
	  echo "---------------------------------------------</br>";
	  for($i=0;$i<$arrlength;$i++){
		  echo $colors[$i];
		   echo "<br>";
	  }
?>  