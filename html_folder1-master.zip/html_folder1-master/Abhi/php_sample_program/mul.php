<?php  
$a = Array(array(2, 3, 4),  
				array(1, 2, 3),  
				array(2, 1, 0)  );
$b = Array(array(1, 2, 3),  
				array(3, 3, 2),  
				array(1, 1, 2)  );

$r=count($a);
$c=count($b[0]);
$p=count($b);
if(count($a[0]) != $p){
    echo "Incompatible matrices";
    exit(0);
}
$result=array();
for ($i=0; $i < $r; $i++){
    for($j=0; $j < $c; $j++){
        $result[$i][$j] = 0;
        for($k=0; $k < $p; $k++){
            $result[$i][$j] += $a[$i][$k] * $b[$k][$j];
        }
    }
}
for($i = 0; $i < $r; $i++){  
		for($j = 0; $j < $c; $j++){  
		   print($result[$i][$j] . " ");  
		}  
		print("<br>");  
	}  
print_r($result);
?> 