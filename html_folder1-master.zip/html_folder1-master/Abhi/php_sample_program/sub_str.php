<?php
	echo substr("Hi Hello How Are You",9)."<br>"; 
	echo substr("Hi Hello How Are You",3,5)."<br>"; 
?>