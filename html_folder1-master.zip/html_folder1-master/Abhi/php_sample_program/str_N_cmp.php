<?php
	echo strcmp("Hello world!","Hello Abhi")."<br>"; 
	echo strncmp("Hello Hi!","Hello",5)."<br>"; 
	echo strcasecmp("HEllO","hello")."<br>"; 
?>