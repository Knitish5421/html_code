<?php
$a=array(1,4,1,2,6,8,4);
print_r(array_unique($a));
print_r(sort($a));
?>
