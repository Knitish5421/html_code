<?php
	$str="ABhinasH kumar";
	echo strtolower($str);
	echo "</br>";
	echo strtoupper($str);
	echo "</br>";
	echo lcfirst($str);
	echo "</br>";
	echo ucfirst($str);
	echo "</br>";
	echo ucwords($str);
	
?> 