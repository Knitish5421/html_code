<?php
	$x = 25;
	$y = 15;
	function myTest() {
		global $x, $y;//global keyword is used to call global variable inside a function
		$y = $x + $y;
	} 
	myTest();  
	echo $y; 
?>