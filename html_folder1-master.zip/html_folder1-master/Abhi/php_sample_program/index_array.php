<?php
	$colours=array("Red","green","blue","black");  
	$colour[0]="orange";
	$colour[1]="pink";
	$colour[2]="yellow";
	$colour[3]="voilet";
	echo "colours are:[ $colours[0], $colours[1],$colours[2],$colours[3] ]</br>"; 
	echo "colour are:[ $colour[0], $colour[1],$colour[2],$colour[3] ]</br>"; 
	echo "-------------------------------</br>";
	foreach ($colours as $value){
		echo "$value <br>";
	}
	echo "-------------------------------</br>";
	foreach ($colour as $value) {
		echo "$value <br>";
	}
	echo "-------------------------------</br>";
	$arrlength=count($colours);
	for($i=0;$i<$arrlength;$i++){
		echo $colours[$i];
		echo "<br>";
	}
	echo "-------------------------------</br>";
	$arrlength1=count($colour);
	for($i=0;$i<$arrlength1;$i++){
		echo $colour[$i];
		echo "<br>";
	}
?> 