<?php
function display() {
    echo "Hello World!!<br>";
}
function add($x,$y){
	$z=$x+$y;
	echo $z;
	echo "</br>";
}
function multiply($x,$y){
	return $x*$y;
}
display();
add(5,6);
$a=multiply(5,4);
echo "$a";
?>