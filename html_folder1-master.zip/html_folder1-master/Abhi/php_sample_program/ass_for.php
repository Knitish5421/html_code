<?php
	$price=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30");  	
	$size = count($price);// find size of the array
	$keys = array_keys($price);// getting the array of keys/index strings

	for($i = 0; $i < $size; $i++)	// using the for loop
	{
		
		echo $keys[$i] ."'s price is". $price[$keys[$i]] ."</br>";
	}
	echo "---------------------------</br></br>";
	function get_value($key1){
		global $size;
		global $keys;
		global $price;
		for($i = 0; $i < $size; $i++){
			if($keys[$i]==$key1){
				echo "matched value for your key ".$keys[$i]." is ".$price[$keys[$i]];
			}
		}
	}
	function get_key($val1){
		global $size;
		global $keys;
		global $price;
		for($i = 0; $i < $size; $i++){
			if($price[$keys[$i]]==$val1){
				echo "matched key for your value ".$price[$keys[$i]]." is ".$keys[$i];
			}
		}
	}
	function get_pos($value){
		global $size;
		global $keys;
		global $price;
		for($i = 0; $i < $size; $i++){
			if($price[$keys[$i]]==$value){
				echo "position for".$price[$keys[$i]]." is ".$i+1;
			}
		}
	}
	get_value("pen");
	echo "</br></br>";
	get_key("300");
	echo "</br></br>";
	get_pos("10");

?>