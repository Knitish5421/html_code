<?php
	$a=array("a"=>52.2,"b"=>13.7,"c"=>0.9);
	echo array_sum($a);
?>
