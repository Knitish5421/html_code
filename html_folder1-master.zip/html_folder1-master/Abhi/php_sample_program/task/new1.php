<?php    
	$price=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30");  
	foreach($price as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "-------sorting bassed on value---------</br>";
	asort($price);
	foreach($price as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "-------reverse sorting bassed on value---------</br>";
	arsort($price);
	foreach($price as $k => $v) {  
	echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "-------sorting bassed on key---------</br>";
	ksort($price);
	foreach($price as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "-------reverse sorting bassed on key---------</br>";
	krsort($price);
	foreach($price as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	
?>    