<?php    
	function My_sort($arr){
		for ($i=0;$i<count($arr);$i++) 
        {
			for ($j=$i+1;$j<count($arr);$j++) 
            {
                if ($arr[$i] >$arr[$j]) 
                {
                    $temp = $arr[$i];
                   $arr[$i] =$arr[$j];
                   $arr[$j]= $temp;
                }
            }
        }
		return $arr;
	}
	$array = array("pen"=>"50","book"=>"300","notebook"=>"30","pencil"=>"5"); 
	$keys = array_keys($array);
	$sorted = array();
	$myarray=array();
	$myarray=My_sort($keys);
	foreach ($myarray as $key) {
		$sorted[$key] = $array[$key];
	}
	foreach($sorted as $k => $v) {  
		echo $k."   ".$v."<br/>";  
	} 
?> 