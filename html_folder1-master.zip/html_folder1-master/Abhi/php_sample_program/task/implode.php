<?php
	$arr = array('Hi','Hello!','How','are','you');
	echo implode($arr)."<br>";
	echo implode(" ",$arr)."<br>";
	echo implode("+",$arr)."<br>";	
	$str = implode("+",$arr);
	$myarr=array();
	$myarr=(explode("+",$str));
	echo "--------</br>";
	print_r($myarr);
	echo "</br>";
	foreach($myarr as $arr){
		echo $arr."</br>";
		
	}
?> 

