<?php    
	function My_sort($arr){
		for ($i=0;$i<count($arr);$i++) 
        {
			for ($j=$i+1;$j<count($arr);$j++) 
            {
                if ($arr[$i] >$arr[$j]) 
                {
                    $temp = $arr[$i];
                   $arr[$i] =$arr[$j];
                   $arr[$j]= $temp;
                }
            }
        }
		return $arr;
	}
	$array = array("pen"=>"50","book"=>"300","notebook"=>"30","pencil"=>"5"); 
	$vals = array_values($array);
	$sorted = array();
	$myarray=array();
	$myarray=My_sort($vals);
	foreach ($myarray as $val) {
		$sorted[$val] = $array[$val];
	}
	echo "original array</br>";
	foreach($array as $k => $v) {  
		echo $k."   ".$v."<br/>";  
	} 
	echo "---------------------</br>";
	echo "sorted array bassed on key </br>";
	foreach($sorted as $k => $v) {  
		echo $k."   ".$v."<br/>";  
	} 
?>