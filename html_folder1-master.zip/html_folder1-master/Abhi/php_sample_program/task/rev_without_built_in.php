<?php    
	$array1=array(1,2,3,4,8,7,6,5,9);  
	$arraylen=count($array1);	
	for($i=$arraylen-1;$i>=0;$i--){
		echo $array1[$i];
		echo "<br>";
	}	
?>   