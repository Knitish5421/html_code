<?php    
	$price=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30");  
	asort($price);
	foreach($price as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo array_search("10",$price);
	ksort($price);
	echo array_search("pen",$price);
	
?>    