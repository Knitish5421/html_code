<?php  
	$a = array(  
				array(2, 3, 4),  
				array(1, 2, 3),  
				array(2, 1, 0)  
			);  
	$b = array(  
				array(1, 2, 3),  
				array(3, 3, 2),  
				array(1, 1, 2)  
			);  
	$rows = count($a);  //no of row
	$cols = count($a[0]); //no of cols 
	print("first matrix is<br>");  
	for($i = 0; $i < $rows; $i++){  
		for($j = 0; $j < $cols; $j++){  
		   print($a[$i][$j] . " ");  
		}  
		print("<br>");  
	} 
	print("second matrix is<br>");  
	for($i = 0; $i < $rows; $i++){  
		for($j = 0; $j < $cols; $j++){  
		   print($b[$i][$j] . " ");  
		}  
		print("<br>");  
	} 
	//Array sub will hold the result and initialize it with 0  
	$sub = array(); 
	for($i = 0; $i < $rows; $i++){  
		for($j = 0; $j < $cols; $j++){ 
			$sub[$i][$j] = 0;
			$sub[$i][$j] = $a[$i][$j] - $b[$i][$j];  
		}  
	}    
	print("Addition of two matrix is: <br>");  
	for($i = 0; $i < $rows; $i++){  
		for($j = 0; $j < $cols; $j++){  
		   print($sub[$i][$j] . " ");  
		}  
		print("<br>");  
	}    
?>  