<?php    
	$array = array("pen"=>"50","book"=>"300","notebook"=>"30","pencil"=>"5"); 
	$keys = array_keys($array);
	$sorted = array();
	$myarray=array();
	function My_sort($arr){
		for ($i=0;$i<count($arr);$i++) 
        {
			for ($j=$i+1;$j<count($arr);$j++) 
            {
                if ($arr[$i] >$arr[$j]) 
                {
                   $temp = $arr[$i];
                   $arr[$i] =$arr[$j];
                   $arr[$j]= $temp;
                }
            }
        }
		return $arr;
	}
	$myarray=My_sort($keys);
	foreach ($myarray as $key) {
		$sorted[$key] = $array[$key];
	}
	echo "original array</br>";
	foreach($array as $k => $v) {  
		echo $k."   ".$v."<br/>";  
	} 
	echo "---------------------</br>";
	echo "sorted array bassed on key </br>";
	foreach($sorted as $k => $v) {  
		echo $k."   ".$v."<br/>";  
	} 

	$size = count($sorted);// find size of the array
	$keys1 = array_keys($sorted);// getting the array of keys/index strings
	echo "---------------------------</br></br>";
	function get_value($key1){
		global $size;
		global $keys1;
		global $sorted;
		for($i = 0; $i < $size; $i++){
			if($keys1[$i]==$key1){
				echo "matched value for your key ".$keys1[$i]." is ".$sorted[$keys1[$i]];
			}	              	
		}  
	}
	function get_key($val1){
		global $size;
		global $keys1;
		global $sorted;
		for($i = 0; $i < $size; $i++){
			if($sorted[$keys1[$i]]==$val1){
				echo "matched key for your value ".$sorted[$keys1[$i]]." is ".$keys1[$i];
			}			                	
		}
	}
	function get_pos($value){
		global $size;
		global $keys1;
		global $sorted;
		for($i = 0; $i < $size; $i++){
			if($sorted[$keys1[$i]]==$value){
				echo "position for ".$sorted[$keys1[$i]]." is ".$i;
			}
			
		}
	}
	get_value("pen");
	echo "</br></br>";
	get_key("300");
	echo "</br></br>";
	get_pos("50");
?>    
