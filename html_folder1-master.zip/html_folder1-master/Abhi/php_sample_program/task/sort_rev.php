<?php    
	$array1=array(1,2,3,4,9,7,6,5,8);  
	$arraylen=count($array1);
	echo "original array</br>";
	for($i=0;$i<$arraylen;$i++){
		echo $array1[$i];
		echo "<br>";
	}	
	echo "-----------------------------</br>";
	echo "reversed array</br>";
	for($i=$arraylen-1;$i>=0;$i--){
		echo $array1[$i];
		echo "<br>";
	}
	echo "-----------------------------</br>";	
	echo "sorted and reversed</br>";
	for ($i=0;$i<$arraylen;$i++) 
        {
			for ($j=$i+1;$j<$arraylen;$j++) 
            {
                if ($array1[$i] >$array1[$j]) 
                {
                    $temp = $array1[$i];
                   $array1[$i] =$array1[$j];
                   $array1[$j]= $temp;
                }
            }
        }
	for($i=$arraylen-1;$i>=0;$i--){
		echo $array1[$i];
		echo "<br>";
	}	
?> 


