<?php
echo readfile("ab.txt");
?>