<?php
	$array = array("pen"=>"50","book"=>"300","notebook"=>"30","pencil"=>"5"); 
	//krsort($array);
	foreach(krsort($array)as $x=>$x_value)
	{
	   echo "Key=" . $x . ", Value=" . $x_value;
	   echo "<br>";
	}
?>