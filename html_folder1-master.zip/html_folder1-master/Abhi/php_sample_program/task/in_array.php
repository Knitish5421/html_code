<?php
	$people = array("Ram", "Sita", "luv", "kush", 23,"sam");

	if (in_array("23", $people, TRUE))
	  {
	  echo "Match found<br>";
	  }
	else
	  {
	  echo "Match not found<br>";
	  } 
	if (in_array(23,$people, TRUE))
	  {
	  echo "Match found<br>";
	  }
	else
	  {
	  echo "Match not found<br>";
	  }
	if (in_array("23", $people))
	  {
	  echo "Match found<br>";
	  }
	else
	  {
	  echo "Match not found<br>";
	  } 
	if (in_array("Ram",$people, TRUE))
	  {
	  echo "Match found<br>";
	  }
	else
	  {
	  echo "Match not found<br>";
	  }
?>