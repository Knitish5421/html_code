<?php  
	$a = array(  
				//array(2, 3, 4),  
				array(1, 2, 3),  
				array(2, 1, 0)  
			);  
	$b = array(  
				array(1, 2, 3),  
				array(3, 3, 2),  
				array(1, 1, 2)  
			);  
	$rows = count($a);  //no of row
	$cols = count($a[0]); //no of cols 
	$b_row=count($b);
	if($cols!= $b_row){
    echo "Incompatible matrices";
    exit(0);
	}
	print("first matrix is<br>");  
	for($i = 0; $i < $rows; $i++){  
		for($j = 0; $j < $cols; $j++){  
		   print($a[$i][$j] . " ");  
		}  
		print("<br>");  
	} 
	print("second matrix is<br>");  
	for($i = 0; $i < $rows; $i++){  
		for($j = 0; $j < $cols; $j++){  
		   print($b[$i][$j] . " ");  
		}  
		print("<br>");  
	} 
	$result=array();
	for ($i=0; $i < $rows; $i++){
		for($j=0; $j < $cols; $j++){
			$result[$i][$j] = 0;
			for($k=0; $k < $rows; $k++){//to calculate sum
				$result[$i][$j] += $a[$i][$k] * $b[$k][$j];
			}
		}
	}
	print("Multiplied matrix<br>");  
	for($i = 0; $i < $rows; $i++){  
			for($j = 0; $j < $cols; $j++){  
				print($result[$i][$j] . " ");  
			}  
				print("<br>");  
	}  
?>  