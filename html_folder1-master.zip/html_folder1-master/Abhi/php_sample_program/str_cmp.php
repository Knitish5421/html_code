<?php
	echo strcmp("Hello world!","Hello world!")."<br>"; // the two strings are equal
	echo strcmp("Hi! Hello","Hello")."<br>"; // string1 is greater than string2
	echo strcmp("Hello ","Hi! Hello")."<br>"; // string1 is less than string2 
?>