<?php    
	$price=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30"); 
	asort($price);
	foreach($price as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "---------</br>";	
	$price1=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30","sharpner"=>"15"); 
	ksort($price1);
	foreach($price1 as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "---------</br>";	
	$price3=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30"); 
	arsort($price3);
	foreach($price3 as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	echo "---------</br>";	
	$price4=array("pen"=>"10","pencil"=>"5","book"=>"300","notebook"=>"30","sharpner"=>"15"); 
	krsort($price4);
	foreach($price4 as $k => $v) {  
		echo $k."'s Price is ".$v."<br/>";  
	} 
	
?>    