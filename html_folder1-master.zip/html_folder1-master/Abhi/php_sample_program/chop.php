<?php
	$str="hello!      ";
	echo strlen($str);
	echo "</br>";
	echo strlen(chop($str));
?> 