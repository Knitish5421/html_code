<?php
	echo strpos("Hi Hello how are you","Hello");
?> 