<?php
	$a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
	$a2=array("e"=>"red","f"=>"black","g"=>"purple");
	$a3=array("a"=>"red","b"=>"black","h"=>"yellow");
	$result=array_diff($a1,$a2,$a3);//a1-a1-a2 only value
	print_r($result);
?>