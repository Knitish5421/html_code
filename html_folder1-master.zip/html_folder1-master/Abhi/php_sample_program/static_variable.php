<?php
function myTest() {
    $x = 0;
    echo $x;
    $x++;
}

myTest();
myTest();
myTest();
?>