<?php
  $cars = array
  (
  array("Volvo",22,18),
  array("BMW",15,13),
  array("Saab",5,2),
  array("Land Rover",17,15)
  );
         /* Accessing multi-dimensional array values */
		foreach($marks as $k => $v) {
			foreach($v as $k1 => $v1) {
				echo $k." marks in  ".$k1." is ".$v1."<br/>";  
			} 
		}
?>
</body>
</html>