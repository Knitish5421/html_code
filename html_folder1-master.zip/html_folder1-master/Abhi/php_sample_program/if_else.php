<?php
$age = 2;

if ($age < 18) {
    echo "Not eligible to vote";
} 
 else {
    echo "Eligible to vote";
}
?>