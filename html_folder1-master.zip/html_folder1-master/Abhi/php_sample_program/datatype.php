<?php  
	$x = 5985;
	var_dump($x);
	echo "<br>";
	$y = 10.365;
	var_dump($y);
	echo "<br>";
	$z = 'Hello world!';
	var_dump($z);
	echo "<br>";
	$a = true;
	var_dump($a);
	echo "<br>";
	$cars = array("Volvo","BMW","Toyota");
	var_dump($cars);
?>  
