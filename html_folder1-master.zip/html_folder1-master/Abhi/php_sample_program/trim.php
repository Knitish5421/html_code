<?php 
$str = "Hello World!"; 
echo trim($str); 
echo "</br>";
echo trim($str, "Hellod!"); 
?> 