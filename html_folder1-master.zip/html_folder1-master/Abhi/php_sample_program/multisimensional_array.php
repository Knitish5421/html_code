<?php
    $marks = array( 
				"mohammad" => array (
					"physics" => 35,
					"maths" => 30,	
					"chemistry" => 39
				),
			
				"qadir" => array (
					"physics" => 30,
					"maths" => 32,
					"chemistry" => 29
				),
            
				"zara" => array (
					"physics" => 31,
					"maths" => 22,
					"chemistry" => 39
				)
			);
         
         /* Accessing multi-dimensional array values */
		foreach($marks as $k => $v) {
			foreach($v as $k1 => $v1) {
				echo $k." marks in  ".$k1." is ".$v1."<br/>";  
			} 
		}
?>
</body>
</html>