<?php
$a1=array("red","green");
$a2=array("blue","yellow");
print_r(array_merge($a1,$a2));
echo "</br>";
echo "----------------------------------------------------------------------------------------------------------</br>";
$a3=array(1,2,3,4,5,6,7,8,9);
print_r(array_reverse($a3));
?>