<?php  
$str="Hello PHP";  
print_r(str_split($str));  
?> 