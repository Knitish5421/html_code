<?php
	echo strcasecmp("Hello world!","HELLO WORLD!")."<br>"; // The two strings are equal
	echo strcasecmp("Hello hi","HELLO")."<br>"; // String1 is greater than string2
	echo strcasecmp("Hello world!","HELLO WORLD! HELLO!")."<br>"; // String1 is less than string2 
?>
 