<?php
	print_r(str_split("Hello"));
	echo "</br>";
	echo"------------------------------------------</br>";
	print_r(str_split("Hello",3));
?>