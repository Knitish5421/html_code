<?php
$numbers = array(1,4, 6,5, 2, 22, 11,1,3);
sort($numbers);
$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
    echo $numbers[$x];
    echo "<br>";
}
echo "---------</br>";
$numbers1 = array(1,4, 6,5, 2, 22, 11,1,3,77,5);
rsort($numbers1);
$arrlength1 = count($numbers1);
for($x = 0; $x < $arrlength1; $x++) {
    echo $numbers1[$x];
    echo "<br>";
}
?>
