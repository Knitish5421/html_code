<!DOCTYPE html>
<html>
<body>

<?php
echo "the even numbers are</br>";
for($i=1;$i<=10;$i++){
	
	if($i%2==0)
	echo "$i</br>";
}
?>
</body>
</html>