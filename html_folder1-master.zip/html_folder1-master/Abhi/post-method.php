<!DOCTYPE html>
<html lang="en">
<head>
    <title>Example of PHP POST method</title>
</head>
<body>
<?php
if(isset($_POST["nam"])){
    echo "<p>Hi, " . $_POST["nam"] . "</p>";
}
?>
<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
    <label for="inputName">Name:</label>
    <input type="text" name="nam" id="inputName">
    <input type="submit" value="Submit">
</form>
</body>