<!DOCTYPE html>
<html>
	<body>
	<?php
	$url = 'ab.json'; // path to your JSON file
$data = file_get_contents($url); // put the contents of the file into a variable
$json = json_decode($data);
foreach ($json as $datas) {
	echo $datas->name . ' , '.$datas->age.'</br>';
	
}
	?>  
	</body>
</html>